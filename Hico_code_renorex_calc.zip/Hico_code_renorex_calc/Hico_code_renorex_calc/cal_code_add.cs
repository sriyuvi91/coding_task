﻿/*
 * Created by Ranorex
 * User: yuvas
 * Date: 17/05/2023
 * Time: 14:07
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.PerformanceData;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;
using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Data;
using Ranorex.Core.Testing;

namespace Hico_code_renorex_calc
{
    /// <summary>
    /// Description of cal_code_add.
    /// </summary>
    [TestModule("C047EBD6-B733-4204-BBAF-91A82DBFFA2D", ModuleType.UserCode, 1)]
    public class cal_code_add : ITestModule
    {
    string _Salary = "ranorex";
    [TestVariable("fbe30d05-5734-473a-b9b6-dab5d979f013")]
    public string Salary
    {
    	get { return _Salary; }
    	set { _Salary = value; }
    }
    
    string _TotalSalary = "";
    [TestVariable("c1da629f-97fc-430d-940a-389ef447f6d6")]
    public string TotalSalary
    {
    	get { return _TotalSalary; }
    	set { _TotalSalary = value; }
    }
    string _Actual_Salary = "renorex";
    [TestVariable("01badca1-a75f-4b71-9028-986afa4bb9f6")]
    public string Actual_Salary
    {
    	get { return _Actual_Salary; }
    	set { _Actual_Salary = value; }
    }
    
    
    string _Bonus = "ranorex";
    [TestVariable("3d7dfa44-ad20-4ed8-bca7-ec02577a4541")]
    public string Bonus
    {
    	get { return _Bonus; }
    	set { _Bonus = value; }
    }
   
    	

        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public cal_code_add()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
            
////////////////////////////      CODE STARTS FROM HERE    ////////////////////////////////////////////////////////////            
// CODE DESCRIPTION : 1. Creating repository 
//					  2. Using spy Tracking finding path for explorer start button and placeholder text to search calculator app by typing calculator.
//					  3. Clearing entry button in order to clear memory (this is done not to pick the previous run value).
//                    4. Adding salary and bonus to get total salary by add operator .
//					  5. Validation is done by using if clause comparing the total_salary(result) with expected salary in the datasource table.
			 var repo = Hico_code_renorex_calcRepository.Instance;
			 var icon = repo.Explorer.Icon;
             			icon.Click();
             var placeholderText = repo.Start.PlaceholderText;                  
                       Keyboard.Press("Calculator");
					   Keyboard.Press(System.Windows.Forms.Keys.Enter);
					   						
			 var calculator1 = repo.Calculator;
			 	 		repo.ClearEntryButton.Click();
			 var textContainer = repo.TextContainer;
					   textContainer.PressKeys(Salary);
					   repo.PlusButton.Click();
					   textContainer.PressKeys(Bonus);
					   repo.EqualButton.Click();
            		   Actual_Salary = textContainer.Caption;
		
/////////////// Validation ////////////////////       
if(Actual_Salary == TotalSalary)
      	 {
      		Report.Info("Addition of two inputs matches expected result - Test case Pass ");
     		var close1 = repo.Close;
     		close1.Click();
      	  }
         
else
	  	 {
      		Report.Info("Test case Failed - Not matched ");
      		var close = repo.Close;
      		close.Click();
      	  }

        }
    }      
}